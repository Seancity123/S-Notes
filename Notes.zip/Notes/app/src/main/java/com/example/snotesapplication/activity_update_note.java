package com.example.snotesapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import java.util.Date;

public class activity_update_note extends AppCompatActivity  {
    private ImageButton backButton;
    private EditText titleText;
    private EditText contentText;
    private MySQLiteHelper db;

    //function to get current note object
    private Note currentNote(String id) {
        db = new MySQLiteHelper(activity_update_note.this);
        Note note = db.getNotes(id);
        db.close();
        return note;
    }

    //function to toast message
    private void showMessage(String message,int period) {
        Toast.makeText(activity_update_note.this, message, period).show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_note);
        //get id from bundle here
        String selectedId = new SharedPreferencesHelper(this).getId();

        titleText = (EditText)findViewById(R.id.titleEditText);
        contentText = (EditText)findViewById(R.id.contentEditText);

        //copy and paste the selected note into edit text
        titleText.setText(currentNote(selectedId).getNoteTitle());
        contentText.setText(currentNote(selectedId).getNoteContent());
        db.close();

        //prevent edit text from losing own value during screen rotation
        String str_title = "", str_content = "";
        if (savedInstanceState != null) {
            str_title = savedInstanceState.getString("title");
            str_content = savedInstanceState.getString("content");
            titleText.setText(str_title);
            contentText.setText(str_content);
            savedInstanceState.clear();
        }

        //actions taken when back button is clicked
        backButton = (ImageButton)findViewById(R.id.backImageButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                back_clicked();
            }
        });
    }

    //function to update existing Note from the database
    public void save_clicked (View view) {
        final String selectedId = new SharedPreferencesHelper(this).getId();
        Note note = currentNote(selectedId);

        //get the string of title and content
        String title = titleText.getText().toString();
        String content = contentText.getText().toString();

        if (title.length() != 0) {
            //update note
            db = new MySQLiteHelper(activity_update_note.this);
            note.setNoteTitle(title);
            note.setNoteContent(content);
            String date = android.text.format.DateFormat.format("yyyy-MM-dd hh:mm:ss a", new java.util.Date()).toString();
            note.setNoteDate(date);
            db.updateNotes(note);

            //send this result to refresh the recyclerview
            Intent intent = getIntent();
            intent.putExtra("UUID", note.getNoteId().toString());
            intent.putExtra("title", note.getNoteTitle());
            intent.putExtra("content", note.getNoteContent());
            intent.putExtra("date", note.getNoteDate());

            //to determine the difference between update and delete
            int noteUpdated = 1;
            intent.putExtra("noteUpdated", noteUpdated);

            setResult(RESULT_OK, intent);

            //tell user note is updated
            showMessage("Updated", Toast.LENGTH_SHORT);
        } else {
            showMessage("Title cannot be empty", Toast.LENGTH_SHORT);
        }
    }

    //function to delete current Note object
    public void delete_clicked (View view) {
        final String selectedId = new SharedPreferencesHelper(this).getId();

        new AlertDialog.Builder(activity_update_note.this)
                .setMessage("Are you sure you want to delete the current note?")
                .setTitle("Delete Note")
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int position) {
                        //* if YES *//
                        db = new MySQLiteHelper(activity_update_note.this);
                        db.deleteNotes(selectedId);
                        db.close();

                        // send this result to refresh the recyclerview
                        Intent intent = getIntent();

                        setResult(RESULT_OK, intent);
                        back_clicked();
                    }
                })
                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int position) {
                        return;
                    }
                })
                .show();
    }

    //function to close the activity_update_note
    private void back_clicked() {
        activity_update_note.this.finish();
    }

    @Override
    public void onBackPressed() {
        back_clicked();
    }

    //prevent edit text from losing own value during screen rotation
    @Override
    protected void onSaveInstanceState (Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("title", titleText.getText().toString());
        outState.putString("content", contentText.getText().toString());
    }
}
