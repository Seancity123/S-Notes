package com.example.snotesapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class MySQLiteHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "SNotes.db";
    private static final String SNOTES_NOTE_TABLE = "snotes";
    private static final String SNOTES_COLUMN_UUID = "UUID";
    private static final String SNOTES_COLUMN_TITLE = "title";
    private static final String SNOTES_COLUMN_CONTENT = "content";
    private static final String SNOTES_COLUMN_DATE = "date";

    private static final String[] COLUMNS = {SNOTES_COLUMN_UUID, SNOTES_COLUMN_TITLE,
            SNOTES_COLUMN_CONTENT,SNOTES_COLUMN_DATE};

    //constructor
    public MySQLiteHelper(Context context){
        super(context,DATABASE_NAME,null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //create snotes table in db
        String CREATE_SNOTES_TABLE = "CREATE TABLE " + SNOTES_NOTE_TABLE +
                "(UUID TEXT PRIMARY KEY, title TEXT, content TEXT, date TEXT );";
        db.execSQL(CREATE_SNOTES_TABLE);
    }

    //function to transfer content of old db to new db
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + SNOTES_NOTE_TABLE);

        //create fresh table
        onCreate(db);
    }

    //function to add note object to db
    public void addNotes (Note note) {
        //get reference
        SQLiteDatabase db = this.getWritableDatabase();
        //create ContentValues to add key "column"/value
        ContentValues cv = new ContentValues();
        cv.put(SNOTES_COLUMN_UUID, note.getNoteId().toString());
        cv.put(SNOTES_COLUMN_TITLE, note.getNoteTitle());
        cv.put(SNOTES_COLUMN_CONTENT, note.getNoteContent());
        cv.put(SNOTES_COLUMN_DATE,note.getNoteDate());

        //insert the values into the TABLE of database
        db.insert(SNOTES_NOTE_TABLE,null,cv);
        cv.clear();
        db.close();
    }

    //function to update existing note objects from db
    public void updateNotes (Note note) {
        //get reference to writable DB
        SQLiteDatabase db = this.getWritableDatabase();
        //create ContentValues to add key "column"/value
        ContentValues cv = new ContentValues();
        cv.put(SNOTES_COLUMN_TITLE, note.getNoteTitle());
        cv.put(SNOTES_COLUMN_CONTENT, note.getNoteContent());
        cv.put(SNOTES_COLUMN_DATE,note.getNoteDate());
        //updating row
        db.update(SNOTES_NOTE_TABLE, //table
                cv, //column/value
                "UUID = ? ", //selections
                new String[] { note.getNoteId().toString() }); //selection args
        //clear the values
        cv.clear();
        db.close();
    }

    //function to delete existing note objects from db
    public void deleteNotes (String UUID) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(SNOTES_NOTE_TABLE, //table
                "UUID = ? ", //selections
                new String[] { String.valueOf(UUID) }); //selection args
        db.close();
    }

    //function to get note object
    public Note getNotes (String id){
        //get reference to readable DB
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(SNOTES_NOTE_TABLE, //table
                        COLUMNS, //column names
                        "UUID = ?", //selections
                        new String[]{id}, //selection args
                        null,//group by
                        null, //having
                        null, //order by
                        null); //limit

        //retrieve first results if available
        if(cursor != null){
            cursor.moveToFirst();
        }

        //create new object
        Note note = new Note(
                cursor.getString(1),
                cursor.getString(2),
                cursor.getString(3));
        note.setNoteId(UUID.fromString(cursor.getString(0)));

        if(cursor != null){
            cursor.close();
        }
        db.close();
        //return the new object
        return note;
    }

    //function to retrieve all notes object
    public List<Note> getAllNotes () {
        List<Note> notesList = new ArrayList<Note>();
        //get reference to readable DB
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + SNOTES_NOTE_TABLE, //table
                        null); //selection args

        //looping through all rows and adding to list
        cursor.moveToFirst();
        while (cursor.isAfterLast() == false) {
            Note note = new Note(
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getString(3));
            note.setNoteId(UUID.fromString(cursor.getString(0)));
            notesList.add(note);
            cursor.moveToNext();
        }
        cursor.close();
        db.close();
        //return notesList
        return notesList;
    }
}
