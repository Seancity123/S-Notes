package com.example.snotesapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.Date;

public class activity_new_note extends AppCompatActivity {
    private ImageButton backButton;
    private ImageButton saveButton;
    private EditText titleText;
    private EditText contentText;
    private RecycleListViewAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_note);

        titleText = (EditText)findViewById(R.id.titleEditText);
        contentText = (EditText)findViewById(R.id.contentEditText);

        //prevent edit text from losing own value during screen rotation
        String str_title = "", str_content = "";
        if (savedInstanceState != null) {
            str_title = savedInstanceState.getString("title");
            str_content = savedInstanceState.getString("content");
            titleText.setText(str_title);
            contentText.setText(str_content);
        }

        //actions taken when back button is clicked
        backButton = (ImageButton)findViewById(R.id.backImageButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                back_clicked();
            }
        });

        //actions taken when save button is clicked
        saveButton = (ImageButton)findViewById(R.id.saveImageButton);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                save_clicked();
            }
        });
    }

    //function for saving Note into the database
    private void save_clicked () {
        //get the string of title and content
        String title = titleText.getText().toString();
        String content = contentText.getText().toString();
        if (title.length() != 0) {
            MySQLiteHelper db = new MySQLiteHelper(this);
            //create new Note object to hold the title, content and date
            String date = android.text.format.DateFormat.format("yyyy-MM-dd hh:mm:ss a", new java.util.Date()).toString();
            Note note = new Note(title, content, date);

            //insert the Note object into database
            db.addNotes(note);
            db.close();

            // send this result to refresh the recyclerview
            Intent intent = getIntent();
            intent.putExtra("UUID", note.getNoteId().toString());
            intent.putExtra("title", note.getNoteTitle());
            intent.putExtra("content", note.getNoteContent());
            intent.putExtra("date", note.getNoteDate());

            setResult(RESULT_OK, intent);

            back_clicked();
        } else {
            Toast.makeText(activity_new_note.this,"Title cannot be empty.",Toast.LENGTH_SHORT).show();
        }
    }

    //function to close the activity_new_note
    private void back_clicked() {
        finish();
    }

    @Override
    public void onBackPressed() {
        back_clicked();
    }

    //prevent edit text from losing own value during screen rotation
    @Override
    protected void onSaveInstanceState (Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("title", titleText.getText().toString());
        outState.putString("content", contentText.getText().toString());
    }
}