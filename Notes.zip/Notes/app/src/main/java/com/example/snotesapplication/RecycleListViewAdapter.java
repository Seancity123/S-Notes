package com.example.snotesapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class RecycleListViewAdapter extends RecyclerView.Adapter<RecycleListViewAdapter.MyNoteHolder> {
    private Context context;
    private List<Note> noteList;
    private LayoutInflater mLayoutInflater;
    private MiddleMan mMiddleMan;

    public interface MiddleMan {
        void itemClicked(int pot);
    }

    //adapter constructor
    public RecycleListViewAdapter(Context context, List<Note> noteList, MiddleMan middleMan) {
        this.context = context;
        this.noteList = new ArrayList<>();
        this.noteList.addAll(noteList);
        this.mMiddleMan = middleMan;

        mLayoutInflater = LayoutInflater.from(context);
    }

    //function used to update noteList of Adapter
    public void addNewNote(Note note) {
        //this code updates the noteList of Adapter
        noteList.add(note);
        //refresh recyclerview
        notifyItemInserted(getItemCount());
    }

    //function used to update noteList of Adapter
    public void updateNote(int pot, Note updateNote) {
        //this code updates the noteList of Adapter
        noteList.set(pot, updateNote);
        //refresh recyclerview
        notifyItemChanged(pot);
    }

    //function used to update noteList of Adapter
    public void deletedNote(int pot) {
        //this code updates the noteList of Adapter
        noteList.remove(pot);
        //refresh recyclerview
        notifyItemRemoved(pot);
        notifyItemRangeChanged(pot, noteList.size());
    }

    @Override
    public RecycleListViewAdapter.MyNoteHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //create a new view
        View v = mLayoutInflater.inflate(R.layout.rlv_note, parent, false);
        MyNoteHolder vh = new MyNoteHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull MyNoteHolder holder, int p) {
        final int position = holder.getAdapterPosition();

        //to display one note object in recycler view
        holder.titleTextView.setText(noteList.get(position).getNoteTitle());
        holder.dateTextView.setText("Last edited at " + noteList.get(position).getNoteDate());

        //when note object is clicked in recycler view
        holder.note_object.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //SharedPreferences helper for storing id
                String strId = noteList.get(position).getNoteId().toString();
                System.out.println("strId: " + strId);

                new SharedPreferencesHelper(context).setId(strId);

                String pot = noteList.get(position).toString();

                //to force Main Activity to call the itemClicked method
                mMiddleMan.itemClicked(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return noteList.size();
    }

    public class MyNoteHolder extends RecyclerView.ViewHolder {
        public TextView titleTextView;
        public TextView dateTextView;
        public LinearLayout note_object;

        public MyNoteHolder(View v) {
            super(v);
            titleTextView = v.findViewById(R.id.titleTextView);
            dateTextView = v.findViewById(R.id.dateTextView);
            note_object = v.findViewById(R.id.noteObject);
        }
    }






}
