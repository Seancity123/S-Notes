package com.example.snotesapplication;

import java.util.UUID;

public class Note {
    private UUID noteId;
    private String noteTitle;
    private String noteContent;
    private String noteDate;

    //constructor
    public Note(String noteTitle, String noteContent, String noteDate) {
        noteId = UUID.randomUUID();
        this.noteTitle = noteTitle;
        this.noteContent = noteContent;
        this.noteDate = noteDate;
    }

    //getter
    public UUID getNoteId() {return noteId;}
    public String getNoteTitle() {return noteTitle;}
    public String getNoteContent() {return noteContent;}
    public String getNoteDate() {return noteDate;}

    //setter
    public void setNoteId(UUID noteId) {this.noteId = noteId;}
    public void setNoteTitle(String noteTitle) {this.noteTitle = noteTitle;}
    public void setNoteContent(String noteContent) {this.noteContent = noteContent;}
    public void setNoteDate(String noteDate) {this.noteDate = noteDate;}

}
