package com.example.snotesapplication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private RecycleListViewAdapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;
    private ImageButton addButton;
    private int REQUEST_CODE_NEW_NOTE = 10;
    private int REQUEST_CODE_UPDATE_NOTE = 20;
    private List<Note> noteList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = (RecyclerView) findViewById(R.id.rlv_noteRecycleView);

        //declares noteList of Main Activity
        noteList = new ArrayList<>();
        noteList = new MySQLiteHelper(this).getAllNotes();

        mAdapter = new RecycleListViewAdapter(this, noteList, new RecycleListViewAdapter.MiddleMan() {
            //used to open note from the recycler view
            @Override
            public void itemClicked(int pot) {
                Intent i = new Intent(MainActivity.this, activity_update_note.class);
                //note position
                i.putExtra("NOTE_POSITION", pot);

                MainActivity.this.startActivityForResult(i, REQUEST_CODE_UPDATE_NOTE);
            }
        });
        recyclerView.setAdapter(mAdapter);

        //linear layout manager
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        //to ensure that the content does not change the layout size of recycle view
        recyclerView.setHasFixedSize(true);

        //actions taken when add button is clicked
        addButton = (ImageButton) findViewById(R.id.addImageButton);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //creates a new intent to launch the activity_new_note.xml screen
                Intent i = new Intent(getApplicationContext(), activity_new_note.class);

                //the below commented code is used to send intent
                startActivityForResult(i, REQUEST_CODE_NEW_NOTE);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //if received the request code for new note
        if (requestCode == REQUEST_CODE_NEW_NOTE) {
            //if received ok
            if (resultCode == RESULT_OK) {
                //creates new note for recyclerview
                String uuid = data.getStringExtra("UUID");
                String title = data.getStringExtra("title");
                String content = data.getStringExtra("content");
                String date = data.getStringExtra("date");
                Note newNote = new Note(title, content, date);
                newNote.setNoteId(UUID.fromString(uuid));

                //this code update the noteList of Main Activity
                noteList.add(newNote);
                //this code updates the noteList of Adapter
                mAdapter.addNewNote(newNote);
            }
        }

        //if received the request code for update
        if (requestCode == REQUEST_CODE_UPDATE_NOTE) {
            //if received ok
            if (resultCode == RESULT_OK) {
                int update = data.getIntExtra("noteUpdated", 0);
                if(update == 1) {
                    //creates new note for recyclerview
                    int pot = data.getIntExtra("NOTE_POSITION", 0);
                    String uuid = data.getStringExtra("UUID");
                    String title = data.getStringExtra("title");
                    String content = data.getStringExtra("content");
                    String date = data.getStringExtra("date");
                    Note updateNote = new Note(title, content, date);
                    updateNote.setNoteId(UUID.fromString(uuid));

                    //this code update the noteList of Main Activity
                    noteList.set(pot, updateNote);
                    //this code updates the noteList of Adapter
                    mAdapter.updateNote(pot, updateNote);
                } else {
                    //gets position of existing note from recyclerview
                    int pot = data.getIntExtra("NOTE_POSITION", 0);

                    //this code update the noteList of Main Activity
                    noteList.remove(pot);
                    //this code updates the noteList of Adapter
                    mAdapter.deletedNote(pot);
                }
            }
        }
    }
}
