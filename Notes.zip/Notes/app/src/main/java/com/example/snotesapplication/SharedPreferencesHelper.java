package com.example.snotesapplication;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPreferencesHelper {
    SharedPreferences sharedpreferences;

    public static final String mypreference = "mypref";
    public static final String NAME = "nameKey";

    //constructor
    public SharedPreferencesHelper(Context context) {
        sharedpreferences = context.getSharedPreferences(mypreference, Context.MODE_PRIVATE);
    }

    //setter
    public void setId(String id) {
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(NAME, id);
        editor.commit();
    }

    //getter
    public String getId() {
        return sharedpreferences.getString(NAME, "");
    }
}
